package com.mie.controller;

import java.io.IOException;
import java.security.acl.Group;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.EventDao;
import com.mie.dao.GroupFilesDao;
import com.mie.dao.GroupMemberDao;
import com.mie.dao.MemberDao;
import com.mie.model.Event;
import com.mie.model.GroupFiles;
import com.mie.model.Member;

public class GroupMemberController {
	
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Event page. EDIT leads to the Edit A Event page.
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String GAC = "/GroupCalendar.jsp";
	private static String LIST_GROUP_ADMIN = "/listGroupAdmin.jsp"; //WHAT IS THIS NAME
	
	private GroupFilesDao groupFilesDao;
	private GroupMemberDao groupMemberDao;
	private MemberDao memberDao;

	/**
	 * Constructor for this class.
	 */
	public GroupMemberController() {
		super();
		groupFilesDao = new GroupFilesDao();
		groupMemberDao = new GroupMemberDao();
		memberDao = new MemberDao();
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - insert will direct the servlet to let the user add a
		 * new event to the database. - edit will direct the servlet to let
		 * the user edit event information in the database.
		 */
		String forward = GAC;
		String action = request.getParameter("action");
		int groupId = Integer.parseInt(request.getParameter("groupId"));
		int memberId = Integer.parseInt(request.getParameter("memberId"));
		GroupFiles group = groupFilesDao.getGroupByID(groupId);

		if (action.equalsIgnoreCase("delete")) {
			groupMemberDao.deleteMember(group, memberId);
	
		} else if (action.equalsIgnoreCase("listStudentAdmin")) {
			forward = LIST_GROUP_ADMIN;
			request.setAttribute("students", groupMemberDao.getAllMembers(groupId)); 
			
		} else if (action.equalsIgnoreCase("insert")) {
			forward = GAC;
			
		}else {
			forward = GAC;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addStudent.jsp or the editStudent.jsp pages.
		 */
		GroupFiles group = new GroupFiles();
		int memberId = Integer.parseInt(request.getParameter("MemberID")); //WHAT WILL BE ENTERED INTO THE FORM?
		Member member = memberDao.getMemberByID(memberId);
		
		
		group.addGroupMember(member);
		
		/**
		 * If the 'memberEmail' field in the form is empty, the new member will
		 * be added to the list of Member objects.
		 */
//		RequestDispatcher view = request
//				.getRequestDispatcher(LIST_STUDENT_ADMIN);
//		request.setAttribute("students", dao.getAllStudents());
//		view.forward(request, response);
		
		
		
		RequestDispatcher view = request
				.getRequestDispatcher(GAC);
		//request.setAttribute("groupMembers", groupMemberDao.getAllMembers());
		view.forward(request, response);
	}
	
}
