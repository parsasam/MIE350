package com.mie.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.model.*;
import com.mie.dao.*;


/**
 * Servlet implementation for SignUpController.
 * 
 * This class handles the sign up servlet and assigns session attributes for users
 * who succesfully sign up into the system.
 */
public class SignUpController extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {
		try {
		
		/**
		 * Retrieve the entered first name, last name, email and password from the SignUp.jsp form.
		 */
		Member member = new Member();
		member.setFirstName(request.getParameter("firstName"));
		member.setLastName(request.getParameter("lastName"));
		member.setEmailAddress(request.getParameter("email"));
		member.setPassword(request.getParameter("psw"));
		
		
		/**
		 * Try to see if the member can log in.
		 */
			boolean result = MemberDao.addMemberBoolean(member);

		/**
		 * If the member can be added, so if the result value is true, assign session attributes to the
		 * current member.
		 */
			if (result) {

				HttpSession session = request.getSession(true);
				session.setAttribute("currentSessionmember", member);
				
				session.setAttribute("email", member.getEmailAddress());
				session.setAttribute("firstname", member.getFirstName());
				session.setAttribute("lastname", member.getLastName());
				//System.out.println("do you even get here?");
				/**
				 * Redirect the members to login.
				 */
				response.sendRedirect("login.jsp"); //Zoairiah: I think if we want them to not send to login but to PersonalCalendar, we need to add whatever LoginController has that checks the member is in the system, on this controller

			}

			else {
				/**
				 * Otherwise, redirect the user to the invalid login page and
				 * ask them to log in again with the proper credentials.
				 */
				response.sendRedirect("invalidLogin.jsp"); //Zoairiah: change the text on invalidLogin.jsp so that it can be used for invalid sign ups as well
			}
		}

		catch (NumberFormatException theException) {
			/**
			 * Print out any errors.
			 */
			response.sendRedirect("invalidLogin.jsp"); //Zoairiah: we need to make a "error displaying" page
			System.out.println(theException);
		}
	}
}
