package com.mie.controller;

import java.io.IOException;
import java.security.acl.Group;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.EventDao;
import com.mie.dao.GroupAvailabilityDao;
import com.mie.dao.GroupFilesDao;
import com.mie.dao.GroupMemberDao;
import com.mie.dao.MemberDao;
import com.mie.model.GroupFiles;
import com.mie.model.Member;
import com.mie.model.Event;


public class GroupAvailabilityController extends HttpServlet {
	
	
	
	private static final long serialVersionUID = 1L;
	private static String PAC = "/GroupCalendar.jsp";
	private static String GAC = "/GroupCalendar.jsp";
	
	private GroupAvailabilityDao groupAvailabilityDao;
	private GroupFilesDao groupFilesDao;
	
	

	/**
	 * Constructor for this class.
	 */
	public GroupAvailabilityController() {
		super();
		groupAvailabilityDao = new GroupAvailabilityDao();
		groupFilesDao = new GroupFilesDao();
		
		
	}
	
	
	
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addStudent.jsp or the editStudent.jsp pages.
		 */
		int groupId = Integer.parseInt(request.getParameter("GroupID")); //WHAT WILL BE ENTERED INTO THE FORM?
		GroupFiles group = groupFilesDao.getGroupByID(groupId);
		
		
		/**
		 * If the 'memberEmail' field in the form is empty, the new member will
		 * be added to the list of Member objects.
		 */
//		RequestDispatcher view = request
//				.getRequestDispatcher(LIST_STUDENT_ADMIN);
//		request.setAttribute("students", dao.getAllStudents());
//		view.forward(request, response);
		
		
		
		RequestDispatcher view = request
				.getRequestDispatcher(GAC);
		request.setAttribute("groupBusyTimes", groupAvailabilityDao.getMergedGroupBusy(group));
		view.forward(request, response);
	}
	
	
	
}
		
