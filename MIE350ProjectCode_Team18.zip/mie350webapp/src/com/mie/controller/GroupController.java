package com.mie.controller;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.GroupFilesDao;
import com.mie.dao.MemberDao;
import com.mie.model.GroupFiles;
import com.mie.model.Member;

public class GroupController {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Student page. EDIT leads to the Edit A Student page.
	 * LIST_STUDENT_PUBLIC leads to the public listing of students.
	 * LIST_STUDENT_ADMIN leads to the admin-only listing of students (for them
	 * to modify student information).
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String GAC = "/GroupCalendar.jsp";


	private GroupFilesDao dao;

	/**
	 * Constructor for this class.
	 */
	public GroupController() {
		super();
		dao = new GroupFilesDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("edit")) {
			forward = GAC;
			int groupID = Integer.parseInt(request.getParameter("groupID"));
			GroupFiles group = dao.getGroupByID(groupID);
			request.setAttribute("group", group);
		} else {
			forward = GAC;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the GroupCalendar.jsp/.
		 */
		GroupFiles group = new GroupFiles();
		group.setGroupName(request.getParameter("GroupName"));
		dao.addGroup(group);
		
		RequestDispatcher view = request
				.getRequestDispatcher(GAC);
		//request.setAttribute("students", dao.getAllStudents());
		view.forward(request, response);
	}
}
