package com.mie.controller;

import java.io.IOException;  
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.EventDao;
import com.mie.dao.MemberDao;
import com.mie.model.Event;
import com.mie.model.Member;

public class EventController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Event page. EDIT leads to the Edit A Event page.
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String PAC = "/PersonalCalendar.jsp";
	

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		try{
			//MAKE SURE PARAMETERS ARE CORRECT 
			
			Event event = new Event();
			String email = request.getParameter("email");
			Member member = MemberDao.getMemberByEmail(email);
			event.setMemberID(member.getMemberID());
			event.setEventName(request.getParameter("EventName"));
			event.setDay(request.getParameter("days")); 
			event.setTime(request.getParameter("time"));
			
			/**
			 * If the 'memberEmail' field in the form is empty, the new member will
			 * be added to the list of Member objects.
			 */
			boolean result = EventDao.addEventBoolean(event);
			
			if (result) {
				
				HttpSession session = request.getSession(true);
				session.setAttribute("currentSessionmember", member);
				session.setAttribute("EventName", event.getEventName());
				session.setAttribute("days", event.getDay());
				session.setAttribute("time", event.getTime());
			}
			
			else {
				response.sendRedirect("PersonalCalendar.jsp");
			}
			
			
			/**if (dao.eventExists(member.getMemberID(), event.getDay(), event.getTime()) == false) { //if day and time doesn't exist with memberid, then add event
				
			} else { //update the event
				dao.updateEvent(event);
			}**/
			/**
			 * Once the student has been added or updated, the page will redirect to
			 * their Personal Calendar.
			 */
			/**RequestDispatcher view = request
					.getRequestDispatcher(PAC);
			//request.setAttribute("students", dao.getAllStudents());
			view.forward(request, response);**/
		
		}
		catch (NumberFormatException e) {
			
			response.sendRedirect("PersonalCalendar.jsp");
			e.printStackTrace();
		}
	}
	
	
}