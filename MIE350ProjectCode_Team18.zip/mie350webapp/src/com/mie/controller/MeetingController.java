package com.mie.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.EventDao;
import com.mie.dao.GroupFilesDao;
import com.mie.dao.GroupMemberDao;
import com.mie.dao.MeetingDao;
import com.mie.dao.MemberDao;
import com.mie.model.Event;
import com.mie.model.Meeting;
import com.mie.model.Member;

public class MeetingController {
	
	private static final long serialVersionUID = 1L;
	private static String GAC = "/GroupCalendar.jsp";
	
	private MeetingDao dao;

	/**
	 * Constructor for this class.
	 */
	public MeetingController() {
		super();
		MeetingDao dao = new MeetingDao();
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - insert will direct the servlet to let the user add a
		 * new meeting to the database. - edit will direct the servlet to let
		 * the user edit meeting information in the database.
		 */
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("insert")) {
			forward = GAC;
		} else if (action.equalsIgnoreCase("edit")) {
			forward = GAC;
			int groupID = Integer.parseInt(request.getParameter("GroupID"));
			int meetingID = Integer.parseInt(request.getParameter("MeetingID"));
			Meeting meeting = dao.getMeetingByID(meetingID);
			//request.setAttribute("member", member);
		} else {
			forward = GAC;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addStudent.jsp or the editStudent.jsp pages.
		 */
		
		//MAKE SURE PARAMETERS ARE CORRECT 
		int meetingID = Integer.parseInt(request.getParameter("meetingID"));
		
		Meeting meeting = new Meeting();
		meeting.setMeetingID(meetingID);
		meeting.setMeetingName(request.getParameter("MeetingName"));
		meeting.setDay(request.getParameter("day")); 
		meeting.setTime(request.getParameter("time"));
		
		/**
		 * If the 'memberEmail' field in the form is empty, the new member will
		 * be added to the list of Member objects.
		 */
		
		if (dao.meetingExists(meetingID, meeting.getDay(), meeting.getTime()) == false) { //if day and time doesn't exist with memberid, then add event
			dao.addMeeting(meeting);
		} else { //update the event
			dao.updateMeeting(meeting);
		}
		/**
		 * Once the student has been added or updated, the page will redirect to
		 * their Personal Calendar.
		 */
		RequestDispatcher view = request
				.getRequestDispatcher(GAC);
		//request.setAttribute("students", dao.getAllStudents());
		view.forward(request, response);
	}
		
		
		
}
