package com.mie.model;

import java.util.Date;

public class Member {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the MembershipFiles object.
	 */
	private int MemberID;
	private String FirstName;
	private String LastName;
	private String Password;
	private String EmailAddress;
	private boolean valid;

	public int getMemberID() {
		return MemberID;
	}

	public void setMemberID(int MemberID) {
		this.MemberID = MemberID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String LastName) {
		this.LastName = LastName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String Password) {
		this.Password = Password;
	}

	public String getEmailAddress() {
		return EmailAddress;
	}

	public void setEmailAddress(String EmailAddress) {
		this.EmailAddress = EmailAddress;
	}

	public boolean isValid() {//COME BACK! check definition later
		return valid;
	}

	public void setValid(boolean newValid) { //come back
		valid = newValid;
	}

	@Override
	public String toString() {
		return "MembershipFiles [MemberID=" + MemberID + ", FirstName=" + FirstName
				+ ", LastName=" + LastName
				+ ", Password=" + Password + ", EmailAddress=" + EmailAddress + "]";
	}
}