package com.mie.model;


public class Meeting {
	
	/* This class contains all of the relevant information, and getter/setter
	 * methods for the Meetings object.
	 */
	private int GroupID;
	private int MeetingID; // do we not need MemberID or ...??
	private String MeetingName;
	private String Day;
	private String Time;

	public int getGroupID() {
		return GroupID;
	}

	public void setGroupID(int GroupID) {
		this.GroupID = GroupID;
	}

	public int getMeetingID() {
		return MeetingID;
	}

	public void setMeetingID(int MeetingID) {
		this.MeetingID = MeetingID;
	}

	public String getMeetingName() {
		return MeetingName;
	}

	public void setMeetingName(String MeetingName) {
		this.MeetingName = MeetingName;
	}

	public String getTime() {
		return Time;
	}
	
	public String getDay() {
		return Day;
	}
	
	public void setTime(String Time) {
		this.Time = Time;
	}
	
	public void setDay(String Day) {
		this.Day = Day;
	}

	@Override
	public String toString() {
		return "Meetings [GroupID=" + GroupID + ", MeetingID=" + MeetingID
				+ ", MeetingName=" + MeetingName + ", Day=" + Day + ", Time=" + Time + "]";
	}
}