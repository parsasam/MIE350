package com.mie.model;

import java.util.ArrayList;

public class GroupFiles {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the GroupFiles object.
	 */
	private int GroupID;
	private String GroupName;
	private ArrayList<Member> groupMembers = new ArrayList<Member>();

	public int getGroupID() {
		return GroupID;
	}

	public void setGroupID(int GroupID) {
		this.GroupID = GroupID;
	}

	public String getGroupName() {
		return GroupName;
	}

	public void setGroupName(String GroupName) {
		this.GroupName = GroupName;
	}
	
	
	public void addGroupMember(Member member) {
		this.groupMembers.add(member);
	}
	
	public ArrayList<Member> getGroupMembers() {
		return groupMembers;
	}
	
	public Member getMemberbyID(int memberID) {
		Member member= new Member();
		java.util.Iterator<Member> i = groupMembers.iterator();
		while (i.hasNext()) {
			member = i.next();
			if (member.getMemberID() == memberID) {
				break;
			}
		}
		return member;
	}
	
	public Member getRecentGroupMember() {
		return groupMembers.get(-1);
	}


	@Override
	public String toString() {
		String string = "GroupMembers [groupid=" + GroupID + ", group name=" + GroupName + ", group members= ";
		java.util.Iterator<Member> i = groupMembers.iterator();
		while (i.hasNext()) {
			Member curMember = i.next();
			string += curMember + ", ";
		}
		return string;
	
}
}