package com.mie.model;


public class Event {
	
	/* This class contains all of the relevant information, and getter/setter
	 * methods for the Meetings object.
	 */
	private int MemberID;
	private int EventID;
	private String EventName;
	private String Day;
	private String Time;


	public int getMemberID() {
		return MemberID;
	}

	public void setMemberID(int MemberID) {
		this.MemberID = MemberID;
	}

	public int getEventID() {
		return EventID;
	}

	public void setEventID(int EventID) {
		this.EventID = EventID;
	}

	public String getEventName() {
		return EventName;
	}

	public void setEventName(String EventName) {
		this.EventName = EventName;
	}

	public String getDay() {
		return Day;
	}
	
	public String getTime() {
		return Time;
	}


	public void setDay(String day) {
		this.Day = day;
		
	}

	public void setTime(String time) {
		this.Time = time;
		
	}


	@Override
	public String toString() {
		return "Events [MemberID=" + MemberID + ", EventID=" + EventID
				+ ", EventName=" + EventName + ", Day=" + Day + ", Time = " + Time + "]";
	}
}