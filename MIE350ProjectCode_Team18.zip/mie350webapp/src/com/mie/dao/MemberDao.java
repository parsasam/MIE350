package com.mie.dao;

import java.sql.Connection;
 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;
import com.mie.util.*;

public class MemberDao {

	/**
	 * This class handles the MembershipFiles objects and the login component of the web
	 * app.
	 */
	private static Connection connection;
	static ResultSet rs;
	
	public MemberDao() {
		connection = DbUtil.getConnection();
	}
	
	//before login method shouldnt we have a MembershipFiles signup/add; getMembersByIds(int memberid); 
	// List<MembershipFiles> getMembersByKeyword(String keyword) --> code found in MeetingsDao.java

	public static Member login(Member member) {

		/**
		 * This method attempts to find the member that is trying to log in by
		 * first retrieving the email address and password entered by the user.
		 */
		Statement stmt = null;

		String EmailAddress = member.getEmailAddress();
		String Password = member.getPassword();

		/**
		 * Prepare a query that searches the members table in the database
		 * with the given username and password.
		 */
		String searchQuery = "SELECT * FROM MembershipFiles WHERE EmailAddress='"
				+ EmailAddress + "' AND Password='" + Password + "'";

		try {
			// connect to DB
			connection = DbUtil.getConnection();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(searchQuery); //Zoairiah: we hadn't initialized rs with anything before
			
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			
			if (!more) {
				member.setValid(false);
			}

			/**
			 * If the query results in an database entry that matches the
			 * email address and password, assign the appropriate information to
			 * the MembershipFiles object.
			 */
			else if (more) {
				String FirstName = rs.getString("FirstName");
				String LastName = rs.getString("LastName");

				member.setFirstName(FirstName);
				member.setLastName(LastName);
				member.setValid(true);
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/**
		 * Return the MembershipFiles object.
		 */
		return member;

	}

	public void deleteMember(int memberID) {
		/**
		 * This method deletes a student from the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from MembershipFiles where MemberID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, memberID);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public Member getMemberByID(int memberID) {
		/**
		 * This method retrieves a student by their StudentID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Member member = new Member();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from MembershipFiles where MemberID=?");
			preparedStatement.setInt(1, memberID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				member.setMemberID(rs.getInt("MemberID"));
				member.setFirstName(rs.getString("FirstName"));
				member.setLastName(rs.getString("LastName"));
				member.setEmailAddress(rs.getString("EmailAddress"));
				member.setPassword(rs.getString("Password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return member;
	}

	public static boolean addMemberBoolean(Member member) {
		/**
		 * This method adds a new student to the database.
		 */
		System.out.print(member.toString() + "\n");
		boolean result = true;
		try {
			connection = DbUtil.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into MembershipFiles(FirstName,LastName,EmailAddress,Password) values (?, ?, ?, ? )"); //Zoairiah: in the database, we use Email instead of EmailAddress 
			// Parameters start with 1
			preparedStatement.setString(1, member.getFirstName());
			preparedStatement.setString(2, member.getLastName());
			preparedStatement.setString(3, member.getEmailAddress());
			preparedStatement.setString(4, member.getPassword());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			result = false;
		}
		return result;
		
	}
	
	public void addMember(Member member) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into MembershipFiles(FirstName,LastName,EmailAddress,Password) values (?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, member.getFirstName());
			preparedStatement.setString(2, member.getLastName());
			preparedStatement.setString(3, member.getEmailAddress());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public void updateMember(Member member) {
		/**
		 * This method updates a student's information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update MembershipFiles set FirstName=?, LastName=?, EmailAddress=?, Password=?"
							+ " where MemberID=?");
			// Parameters start with 1
			preparedStatement.setString(1, member.getFirstName());
			preparedStatement.setString(2, member.getLastName());
			preparedStatement.setString(3, member.getEmailAddress());
			preparedStatement.setString(4, member.getPassword());
			preparedStatement.setInt(5, member.getMemberID());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	public static Member getMemberByEmail(String email) {
		/**
		 * This method retrieves a student by their StudentID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Member member = new Member();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from MembershipFiles where EmailAddress=?");
			preparedStatement.setString(1, email);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				member.setMemberID(rs.getInt("MemberID"));
				member.setFirstName(rs.getString("FirstName"));
				member.setLastName(rs.getString("LastName"));
				member.setEmailAddress(rs.getString("EmailAddress"));
				member.setPassword(rs.getString("Password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return member;
	}
}
