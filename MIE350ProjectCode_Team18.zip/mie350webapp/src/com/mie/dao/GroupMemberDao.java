package com.mie.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;

import com.mie.util.*;
public class GroupMemberDao {

	/**
	 * This class handles the MembershipFiles objects and the login component of the web
	 * app.
	 */
	private Connection connection;

	public GroupMemberDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}
	
	
	public void addMember2Group(GroupFiles group, Member member) { 
		/**
		 * This method adds a member(s) to a common group to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO GroupMembers(GroupID,MemberID) VALUES (?, ?)");
			// Parameters start with 1
			preparedStatement.setInt(1, group.getGroupID()); 
			preparedStatement.setInt(2, member.getMemberID());

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	public void deleteMember(GroupFiles group, int memberID) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("DELETE FROM GroupMembers WHERE GroupID = ? AND MemberID = ?");
			// Parameters start with 1
			preparedStatement.setInt(1, group.getGroupID()); 
			preparedStatement.setInt(2, memberID);

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Member> getAllMembers(int groupID) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		ArrayList<Member> members = new ArrayList<Member>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT MemberID FROM GroupMembers WHERE GroupID = ?");
			// System.out.println("getting students from table");
			preparedStatement.setInt(1, groupID);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				Member member = new Member();
				member.setMemberID(rs.getInt("MemberID"));
				member.setFirstName(rs.getString("FirstName"));
				member.setLastName(rs.getString("LastName"));
				member.setEmailAddress(rs.getString("EmailAddress"));
				member.setPassword(rs.getString("Password"));
				members.add(member);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return members;
	}


}
