package com.mie.dao;

import java.sql.Connection;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Event;
import com.mie.model.Meeting;
import com.mie.util.DbUtil;

public class MeetingDao {
	/**
	 * This class handles all of the Meetings-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public MeetingDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addMeeting(Meeting meeting) {
		/**
		 * This method adds a new meeting to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO Meetings(GroupID,MeetingID,MeetingName,BusySlot) VALUES (?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setInt(1, meeting.getGroupID()); // we may need to input this..
			preparedStatement.setInt(2, meeting.getMeetingID()); // not sure 
			preparedStatement.setString(3, meeting.getMeetingName());
			preparedStatement.setString(4, meeting.getDay());
			preparedStatement.setString(5, meeting.getTime());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updatePACs(Meeting meeting) { //NEED TO UPDATE BECAUSE IT IS INCOMPLETE
		/**
		 * This method adds a meeting(s) to all individuals' PAC within the same GroupID to the database.
		 */
		try {
			int groupId = meeting.getGroupID();
			
			
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO Event(GroupID,MeetingID,MeetingName,Day, Time) VALUES (?, ?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setInt(1, meeting.getGroupID()); // we may need to input this..
			preparedStatement.setInt(2, meeting.getMeetingID()); // not sure 
			preparedStatement.setString(3, meeting.getMeetingName());
			preparedStatement.setString(4, meeting.getDay());
			preparedStatement.setString(5, meeting.getTime());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateMeeting(Meeting meeting) { // are we implementing updating meetings?
		/**
		 * This method updates a meeting's information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("UPDATE Meetings SET MeetingName=?, Day=?, Time=?"
							+ " WHERE MeetingID=? AND GroupID=?");
			// Parameters start with 1
			preparedStatement.setString(1, meeting.getMeetingName());
			preparedStatement.setString(2, meeting.getDay());
			preparedStatement.setString(2, meeting.getTime());
			preparedStatement.setInt(3, meeting.getMeetingID());
			preparedStatement.setInt(4, meeting.getGroupID());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

	public Meeting getMeetingByID( int meetingid) {
		/**
		 * This method retrieves a group meeting by their GroupID and MeetingID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Meeting meeting = new Meeting();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT * FROM Meetings WHERE MeetingID=?");
			preparedStatement.setInt(1, meetingid);

			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				meeting.setMeetingID(rs.getInt("MeetingID"));
				meeting.setGroupID(rs.getInt("GroupID"));
				meeting.setMeetingName(rs.getString("MeetingName"));
				meeting.setDay(rs.getString("Day"));
				meeting.setTime(rs.getString("Time"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return meeting;
	}

	public boolean meetingExists(int groupID, String day, String time) {
		boolean exists = false;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Meetings where GroupID =?, Day = ?, Time = ?");
			preparedStatement.setInt(1, groupID);
			preparedStatement.setString(2, day);
			preparedStatement.setString(3, time);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs.next()) {
				exists = true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return exists;
	}

	



}