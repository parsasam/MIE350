package com.mie.dao;

import java.sql.Connection;  
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;
import com.mie.util.*;

public class GroupFilesDao {

	/**
	 * This class handles all of the GroupFiles-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public GroupFilesDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addGroup(GroupFiles group) {
		/**
		 * This method adds a new group to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO GroupFiles(GroupName) VALUES (?)");
			// Parameters start with 1
			preparedStatement.setString(1, group.getGroupName());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	public GroupFiles getGroupByID(int groupID) {
		// TODO Auto-generated method stub
		GroupFiles group = new GroupFiles();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from GroupFiles where GroupID=?");
			preparedStatement.setInt(1, groupID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				group.setGroupID(rs.getInt("GroupID"));
				group.setGroupName(rs.getString("GroupName"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return group;
	}
	
	

	
	

}