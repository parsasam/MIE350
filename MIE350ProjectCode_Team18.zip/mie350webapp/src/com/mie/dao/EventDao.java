package com.mie.dao;

import java.sql.Connection;     
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Event;
import com.mie.model.Meeting;
import com.mie.model.Member;
import com.mie.util.DbUtil;

public class EventDao {
	/**
	 * This class handles all of the Events-related methods
	 * (add/update/delete/get).
	 */

	private static Connection connection;

	public EventDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addEvent(Event event) {
		/**
		 * This method adds a new event to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("INSERT INTO Events(MemberID,EventName, Day, Time) VALUES (?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setInt(1, event.getMemberID());
			preparedStatement.setString(2, event.getEventName());
			preparedStatement.setString(3, event.getDay());
			preparedStatement.setString(4, event.getTime());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateEvent(Event event) { 
		/**
		 * This method updates an event(s) on the PAC.
		 * This method updates a event's information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("UPDATE Events SET EventName = ? , Day= ? , Time = ?  WHERE MemberID = ?");
			// Parameters start with 1
			preparedStatement.setString(1, event.getEventName());
			preparedStatement.setString(2, event.getDay());
			preparedStatement.setString(3, event.getTime());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Event getEventByID(int eventID) {
		// TODO Auto-generated method stub
		/**
		 * This method retrieves a student by their StudentID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Event event = new Event();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT * from Events WHERE EventID=?");
			preparedStatement.setInt(1, eventID);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				event.setMemberID(rs.getInt("MemberID"));
				event.setEventName(rs.getString("EventName"));
				event.setDay(rs.getString("Day"));
				event.setTime(rs.getString("Time"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return event;
	}
	

	public ArrayList<Event> getEventsByMemberID (int memberid) {
		ArrayList<Event> events = new ArrayList<Event>();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Events where MemberID =?");
			preparedStatement.setInt(1, memberid);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				Event event = new Event();
				event.setMemberID(rs.getInt("MemberID"));
				event.setEventName(rs.getString("EventName"));
				event.setDay(rs.getString("Day"));
				event.setTime(rs.getString("Time"));
				events.add(event);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return events;
		
	}
	
	
	public boolean eventExists (int memberid, String day, String time) {
		boolean exists = false;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Events where MemberID =?, Day = ?, Time = ?");
			preparedStatement.setInt(1, memberid);
			preparedStatement.setString(2, day);
			preparedStatement.setString(3, time);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs.next()) {
				exists = true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return exists;
	}

	public static boolean addEventBoolean(Event event) {
		/**
		 * This method adds a new student to the database.
		 */
		System.out.print(event.toString() + "\n");
		boolean result = true;
		try {
			connection = DbUtil.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Events(MemberID,EventName,Day,Time) values (?, ?, ?, ? )"); //Zoairiah: in the database, we use Email instead of EmailAddress 
			// Parameters start with 1
			preparedStatement.setInt(1, event.getMemberID());
			preparedStatement.setString(2, event.getEventName());
			preparedStatement.setString(3, event.getDay());
			preparedStatement.setString(4, event.getTime());
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}



	

}
