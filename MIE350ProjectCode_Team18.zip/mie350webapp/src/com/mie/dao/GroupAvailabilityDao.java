package com.mie.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import com.mie.model.Event;
import com.mie.model.GroupFiles;
import com.mie.model.Member;
import com.mie.util.DbUtil;

public class GroupAvailabilityDao {
	

	private Connection connection;

	public GroupAvailabilityDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}
	
	
	
	
	public HashMap<String, ArrayList<String>> getMergedGroupBusy(GroupFiles group) {
		
		EventDao eventDao = new EventDao();
		GroupMemberDao groupMemberDao = new GroupMemberDao();
		
		
		ArrayList<String> days = new ArrayList<String>();
		days.add("Monday");
		days.add("Tuesday");
		days.add("Wednesday");
		days.add("Thursday");
		days.add("Friday");
		
		HashMap<String, ArrayList<String>> busyTimes = new HashMap<String, ArrayList<String>>(); //String is the Day, the ArrayList is the times
		for (int i = 0; i <days.size(); i++) {
			ArrayList<String> times = new ArrayList<String>();
			busyTimes.put(days.get(i), times);
		}

		
		ArrayList<Member> membersInGroup = groupMemberDao.getAllMembers(group.getGroupID());
		 
		if (!membersInGroup.isEmpty()) {
			for (int i =0; i <membersInGroup.size(); i++) {
				Member curmember = membersInGroup.get(i);
				ArrayList<Event> listOfEvents = eventDao.getEventsByMemberID(curmember.getMemberID());
				for (int j =0; j <listOfEvents.size(); j++) {
					Event curevent = listOfEvents.get(j);
					String day = curevent.getDay();
					String time = curevent.getTime();
					if (!busyTimes.get(day).contains(time)) {
						busyTimes.get(day).add(time);
					}
				}
			}
		 

		}	
		return busyTimes;

}
	

}
